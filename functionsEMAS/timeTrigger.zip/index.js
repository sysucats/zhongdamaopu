const countPhotoHandler = require('./countPhoto.js')
const getBadgeRankHandler = require('./getBadgeRank.js')
const getPhotoRankHandler = require('./getPhotoRank.js')

module.exports = async (ctx) => {
    if (ctx.args?.deploy_test === true) {
        return "timeTrigger_v1.0"
    }

    return await Promise.all([
        countPhotoHandler(ctx),
        getBadgeRankHandler(ctx),
        getPhotoRankHandler(ctx),
    ])
}
